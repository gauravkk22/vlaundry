
The materials are provided as FREEWARE for your enjoyment, 
but should not be used for any commercial purpose. (This Read must be include with this font.)

Introduction
~~~~~~~~~~~~
Thank you for downloading my "Empire State Deco.ttf" Fonts TTF for Windows, I hope you enjoy using it. 

Requirements
~~~~~~~~~~~~
Windows 98,2000,Me�,XP�

Install
~~~~~~~
1. UnZip, install into C:\windows\fonts.

Uninstall
~~~~~~~~~
Delete the Startup\Settings\Control Panel\Fonts\(highlight font to be deleted)File\Delete.

Created By
~~~~~~~~~~
Date:10/28/2006
Filename: Empire State Deco.ttf.zip 
Title: Empire State Deco
Category:
Archive: Fonts


Suggestions or comments sent to Steve Ferrera : supercarguy@hotmail.com
ENJOY!!!






RuFus


